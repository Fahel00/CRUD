README - Interface CRUD com Servlet, Base de Dados e Uma Classe



Este projeto demonstra a criação de uma interface CRUD (Create, Read, Update, Delete) simples utilizando Servlets do Java para manipulação de dados em uma base de dados. A aplicação utiliza apenas uma classe para gerenciar todas as operações CRUD, simplificando a estrutura do código.



Índice

1. Descrição do Projeto

2. Tecnologias Utilizadas

3. Estrutura do Projeto

4. Configuração do Ambiente

5. Base de Dados

6. Funcionalidades

7. Como Executar o Projeto

8. Considerações Finais



Descrição do Projeto

Este projeto implementa uma interface web simples para realizar operações CRUD em uma tabela de banco de dados. A aplicação foi desenvolvida utilizando Servlets do Java, que processam as requisições HTTP enviadas pelo cliente (navegador). Todas as operações CRUD são gerenciadas por uma única classe, que encapsula a lógica de comunicação com o banco de dados.



O objetivo é demonstrar como é possível criar uma aplicação funcional com uma abordagem minimalista, mantendo o código organizado e eficiente.



Tecnologias Utilizadas

- Java: Linguagem principal utilizada para o desenvolvimento.

- Servlets: Framework para processamento de requisições HTTP.

- JDBC (Java Database Connectivity): API para conexão e manipulação do banco de dados.

- MySQL: Sistema de gerenciamento de banco de dados relacional.

- Apache Tomcat: Servidor de aplicação Java EE para execução dos Servlets.

- HTML/CSS: Front-end básico para exibição da interface.



Estrutura do Projeto

projeto-crud-servlet/

│

├── src/

│   └── com.example.crud/

│       └── CrudServlet.java      # Classe principal que implementa todas as operações CRUD

│

├── WebContent/

│   ├── index.html                # Página inicial com links para as operações CRUD

│   ├── adicionarUtilizador.jsp                  # Formulário para adicionar um novo registro

│   ├── editarUtilizador.jsp 			# Formulário para editar um registro existente

│   ├── listarUtilizadores.jsp                # Formulário para listar registros existentes

│   └── WEB-INF/

│       └── web.xml               # Configuração do Servlet no servidor

│

├── lib/

│   └── mysql-connector-java.jar  # Driver JDBC para MySQL

│

└── README.txt                    # Documentação do projeto



Configuração do Ambiente

1. Instale o JDK: Certifique-se de ter o Java Development Kit (JDK) instalado em sua máquina.

2. Configure o Apache Tomcat: Baixe e instale o servidor Apache Tomcat para executar os Servlets.

3. Driver JDBC: Adicione o arquivo mysql-connector-java.jar ao diretório lib do seu projeto.

4. IDE: Recomenda-se o uso de uma IDE como Eclipse ou IntelliJ IDEA para facilitar o desenvolvimento.



Base de Dados

A aplicação utiliza uma tabela simples no MySQL para armazenar os dados



Certifique-se de configurar as credenciais de acesso ao banco de dados no código-fonte (CrudServlet.java):



String url = "jdbc:mysql://localhost:3306/fcsp2025";

String usuario = "root";

String senha = "sua_senha";



Funcionalidades

A aplicação oferece as seguintes funcionalidades CRUD:



1. Create (Criar):

   - Permite adicionar um novo registro à tabela usuarios.

   - Implementado através de um formulário HTML (add.html) e processado pelo método POST no Servlet.



2. Read (Ler):

   - Exibe todos os registros da tabela usuarios em uma lista.

   - Implementado através de uma consulta SQL (SELECT * FROM usuarios) e exibido em uma página HTML.



3. Update (Atualizar):

   - Permite editar um registro existente na tabela usuarios.

   - Implementado através de um formulário HTML (edit.html) e processado pelo método POST no Servlet.



4. Delete (Excluir):

   - Remove um registro específico da tabela usuarios.

   - Implementado através de um link ou botão que envia uma requisição GET ao Servlet.


Fase de Execução:


1. Importando o Projeto:

   - Abra o projeto em sua IDE preferida.

   - Configure o servidor Apache Tomcat no ambiente de desenvolvimento.



2. Configurando a Base de Dados:

   - Execute o script SQL fornecido acima para criar a tabela usuarios.



3. Executando o Projeto:

   - Inicie o servidor Tomcat.

   - Acesse a aplicação no navegador através do endereço:

     http://localhost:8080/projeto-crud-servlet/



4. Testando Funcionalidades:

   - Use as páginas HTML para adicionar, visualizar, editar e excluir registros.



Considerações Finais

Este projeto é um exemplo básico de como implementar uma interface CRUD utilizando Servlets e uma base de dados. Ele foi projetado para ser simples e didático, ideal para iniciantes que desejam entender os conceitos fundamentais de desenvolvimento web com Java.



Para melhorar a aplicação, você pode considerar:

- Adicionar validação de campos.

- Implementar autenticação e autorização.

- Melhorar o design da interface com CSS e JavaScript.

- Utilizar frameworks como JSP ou Spring MVC para simplificar o desenvolvimento.



Autor: Fahel Aziz

Data: 22/03/25

